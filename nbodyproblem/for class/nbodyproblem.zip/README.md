## N Body Problem

This is the current version of my N Body Problem script, as well as a few gifs to showcase the results. nbodyproblem.py is the script, requires python 3.8+.

### GIFs:
- oops.gif: a strange (but interesting looking) mistake made while trying to create variable width trails
- forever.gif: showing the total paths of the bodies
- follow.gif: following one body throughout
- real.gif: the regular simulation